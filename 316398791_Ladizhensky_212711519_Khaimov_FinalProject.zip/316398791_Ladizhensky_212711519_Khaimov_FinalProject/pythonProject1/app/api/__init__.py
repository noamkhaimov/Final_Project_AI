"""
Flask blueprints for the application's REST API and Swagger documentation.

The API provides endpoints for:
• POST /papers  – Upload one or more PDFs and push them to ChromaDB
• POST /query   – Retrieve context from ChromaDB and ask the LLM
• GET /pdf/files – List all uploaded PDF files
• GET /pdf/files/<file_id> – Get details of a specific PDF file
• GET /logs/application – Get application logs
"""

from .endpoints import (
    api_bp,
    upload_papers,
    query,
    list_pdf_files,
    get_pdf_file,
    get_application_logs
)
from .swagger import swagger_bp, SWAGGER_SPEC

