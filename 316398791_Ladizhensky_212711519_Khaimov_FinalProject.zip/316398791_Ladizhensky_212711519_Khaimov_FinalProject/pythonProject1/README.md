# PDF RAG Application

A containerized Flask application that implements Retrieval-Augmented Generation (RAG) for PDF documents using ChromaDB, MongoDB, and Ollama.

## Architecture

The application consists of several microservices:

- **Backend (Flask)**: Handles API endpoints, PDF processing, and RAG operations
- **ChromaDB**: Vector database for storing document embeddings
- **MongoDB**: Document store for metadata and user data
- **Ollama**: Local LLM service for text generation
- **Mongo Express**: Web-based MongoDB admin interface

## Prerequisites

- Docker and Docker Compose
- Git
- At least 16GB RAM recommended for running the LLM

## Project Structure

```
.
├── app/
│   ├── api/                          # API endpoints and Swagger documentation
│   │   ├── __init__.py              # API blueprint initialization
│   │   ├── endpoints.py             # REST API endpoint implementations
│   │   └── swagger.py               # Swagger/OpenAPI specifications
│   │
│   ├── database/                    # Database clients
│   │   ├── __init__.py             # Database module initialization
│   │   ├── chroma_client.py        # ChromaDB vector store client
│   │   └── mongo_client.py         # MongoDB client implementation
│   │
│   ├── rag/                        # RAG (Retrieval Augmented Generation)
│   │   ├── __init__.py            # RAG module initialization
│   │   ├── chain.py               # RAG chain implementation
│   │   ├── output_parser.py       # LLM output parsing utilities
│   │   └── prompt_templates.py    # LLM prompt templates
│   │
│   ├── utils/                     # Utility functions
│   │   ├── __init__.py           # Utils module initialization
│   │   ├── embeddings.py         # Text embedding utilities
│   │   ├── logging.py            # Logging configuration
│   │   └── pdf_processor.py      # PDF processing utilities
│   │
│   ├── __init__.py               # Main app initialization
│   ├── config.py                 # Application configuration
│   ├── main.py                   # Application entry point
│   └── models.py                 # Data models and schemas
│
├── modelfile/                    # Ollama model configuration
│   └── Modelfile                # Custom LLM model definition
│
├── uploads/                     # Directory for uploaded PDFs
├── docker-compose.yml          # Container orchestration
├── Dockerfile                  # Backend service build configuration
└── README.md                   # Project documentation
```

### Key Components

1. **API Layer** (`app/api/`):
   - `endpoints.py`: Implements REST endpoints for PDF upload, querying, and management
   - `swagger.py`: OpenAPI/Swagger documentation and schemas
   
2. **Database Layer** (`app/database/`):
   - `chroma_client.py`: Manages vector embeddings storage and retrieval
   - `mongo_client.py`: Handles document metadata and user data storage

3. **RAG Implementation** (`app/rag/`):
   - `chain.py`: Core RAG chain implementation for document querying
   - `output_parser.py`: Structures and formats LLM responses
   - `prompt_templates.py`: Defines LLM interaction templates

4. **Utilities** (`app/utils/`):
   - `embeddings.py`: Text embedding generation
   - `logging.py`: Application logging setup
   - `pdf_processor.py`: PDF document processing and text extraction

5. **Model Configuration** (`modelfile/`):
   - `Modelfile`: Defines the custom Ollama model configuration

## Quick Start

1. Run Docker compose:
   ```bash
   docker compose build
   ```
   Note that the flask image can be either downloaded from Dockerhub or built locally. 
   In order to download from Dockerhub please modify the `docker-compose.yml`: remove the `build: .` line and uncomment the `image: ...` line.
2. Start the services:
   ```bash
   docker-compose up
   ```

3. Access the services:
   - Flask Backend: http://localhost:5000
   - Mongo Express: http://localhost:8081
   - ChromaDB: http://localhost:8000
   - Ollama: http://localhost:11434

## API Endpoints

The application provides RESTful APIs for:
- PDF document upload and processing
- Document querying using RAG
- Document management

Detailed API documentation is available via Swagger UI at: http://localhost:5000/api/docs

## Environment Variables

Key environment variables used in the application:

```
FLASK_ENV=development
MONGO_URI=mongodb://mongodb:27017
MONGO_DB=pdf_upload_db
CHROMA_HOST=chromadb
OLLAMA_MODEL=academic
OLLAMA_API_BASE=http://ollama:11434
```

## Persistent Storage

The application uses Docker volumes for persistent storage:
- `pdf_storage`: Uploaded PDF documents
- `chroma_storage`: Vector embeddings
- `ollama_storage`: LLM model data
- `mongo_data`: MongoDB data

## Development

### Adding New Dependencies

1. Add new Python packages to `requirements.txt`
2. Rebuild the backend service:
   ```bash
   docker-compose build backend
   ```

### Code Structure

- `app/api/endpoints.py`: REST API endpoints
- `app/rag/chain.py`: RAG chain implementation
- `app/database/`: Database client implementations
- `app/utils/`: Helper functions for PDF processing and embeddings

## Troubleshooting

1. **MongoDB Connection Issues**
   - Ensure the MongoDB service is running: `docker-compose ps`
   - Check MongoDB logs: `docker-compose logs mongodb`

2. **ChromaDB Issues**
   - Verify ChromaDB is running: `docker-compose ps`
   - Check ChromaDB logs: `docker-compose logs chromadb`

3. **Ollama Model Loading**
   - Check if model is downloaded: `docker-compose exec ollama ollama list`
   - View Ollama logs: `docker-compose logs ollama`

